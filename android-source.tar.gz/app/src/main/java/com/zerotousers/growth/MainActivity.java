package com.zerotousers.growth;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(247, 248, 252);
    private static final int CARD = Color.WHITE;
    private static final int INK = Color.rgb(25, 29, 45);
    private static final int MUTED = Color.rgb(112, 119, 139);
    private static final int PURPLE = Color.rgb(87, 82, 211);
    private static final int LINE = Color.rgb(232, 234, 242);
    private Db db;
    private long businessId = -1;
    private String businessName = "No business";
    private String tab = "Overview";
    private LinearLayout root, body, header, activeCard;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        db = new Db(this);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        selectSavedBusiness();
        render();
    }

    private void selectSavedBusiness() {
        long saved = getPreferences(0).getLong("business_id", -1);
        Cursor c = db.listBusinesses();
        boolean found = false;
        while (c.moveToNext()) {
            if (c.getLong(c.getColumnIndexOrThrow("id")) == saved) {
                businessId = saved; businessName = c.getString(c.getColumnIndexOrThrow("name")); found = true; break;
            }
        }
        if (!found && c.moveToFirst()) {
            businessId = c.getLong(c.getColumnIndexOrThrow("id"));
            businessName = c.getString(c.getColumnIndexOrThrow("name"));
            getPreferences(0).edit().putLong("business_id", businessId).apply();
        }
        c.close();
    }

    private void render() {
        activeCard = null;
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(20), dp(18), dp(20), dp(10)); header.setBackgroundColor(BG);
        LinearLayout brandRow = new LinearLayout(this); brandRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("zero", 25, INK, true); TextView brand2 = text("to", 25, PURPLE, true); TextView brand3 = text("users", 25, INK, true);
        brandRow.addView(brand); brandRow.addView(brand2); brandRow.addView(brand3);
        View spacer = new View(this); brandRow.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1));
        TextView badge = text("FREE • LOCAL", 10, PURPLE, true); badge.setPadding(dp(10), dp(7), dp(10), dp(7)); badge.setBackground(round(Color.rgb(239,238,255), 30)); brandRow.addView(badge);
        header.addView(brandRow);
        TextView sub = text("Your small-business growth desk", 13, MUTED, false); sub.setPadding(0, dp(2), 0, dp(14)); header.addView(sub);
        Button businessButton = button("▦   " + businessName + "    ▾", false); businessButton.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); businessButton.setOnClickListener(v -> chooseBusiness()); header.addView(businessButton);
        root.addView(header);

        LinearLayout nav = new LinearLayout(this); nav.setPadding(dp(12), dp(4), dp(12), dp(10)); nav.setBackgroundColor(BG);
        String[] tabs = {"Overview", "Content", "Inbox", "Leads", "Setup"};
        for (String t : tabs) {
            Button b = new Button(this); b.setText(t); b.setAllCaps(false); b.setTextSize(11); b.setMinHeight(dp(38)); b.setMinimumHeight(dp(38)); b.setPadding(dp(9), 0, dp(9), 0);
            b.setTextColor(tab.equals(t) ? Color.WHITE : MUTED); b.setBackground(round(tab.equals(t) ? PURPLE : Color.WHITE, 14));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1); p.setMargins(dp(2), 0, dp(2), 0); nav.addView(b, p);
            b.setOnClickListener(v -> { tab = t; render(); });
        }
        root.addView(nav);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(18), dp(8), dp(18), dp(28));
        scroll.addView(body); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        if (businessId < 0) emptyState(); else showTab();
        setContentView(root);
    }

    private void showTab() {
        switch (tab) {
            case "Content": showContent(); break;
            case "Inbox": showInbox(); break;
            case "Leads": showLeads(); break;
            case "Setup": showSetup(); break;
            default: showOverview(); break;
        }
    }

    private void emptyState() {
        card(body);
        title(body, "Start with your first business");
        paragraph(body, "Keep each business separate: its social profiles, content, inbox and leads will live in its own workspace on this phone.");
        addButton(body, "+  Create first business", true, this::showAddBusiness);
    }

    private void showOverview() {
        title(body, "Overview"); paragraph(body, "A clear view of this business. Switch workspace to manage another brand.");
        LinearLayout stats = new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stat(stats, "CHANNELS", db.count("channels", businessId)); stat(stats, "CONTENT", db.count("posts", businessId));
        stat(stats, "LEADS", db.count("leads", businessId)); stat(stats, "INBOX", db.count("inbox_notes", businessId));
        body.addView(stats, matchWrap());
        sectionTitle(body, "Quick actions");
        addButton(body, "+  Plan a post", true, () -> showAddPost());
        addButton(body, "+  Add a lead", false, () -> showAddLead());
        addButton(body, "+  Log a DM or comment", false, () -> showAddInbox());
        sectionTitle(body, "Your workspace");
        card(body);
        title(body, businessName);
        paragraph(body, "This workspace has its own social profiles, posts, inbox notes, leads and reply-rule drafts. Data is stored locally on this device.");
        smallNote(body, "API connections are not active in this starter build. Official platform access will be added only after the required approvals and credentials are available.");
    }

    private void showContent() {
        title(body, "Content planner"); paragraph(body, "Prepare posts for this business, then share them to the platform app. This version does not auto-publish in the background.");
        addButton(body, "+  New post", true, this::showAddPost);
        Cursor c = db.list("posts", businessId); boolean any = false;
        while (c.moveToNext()) {
            any = true; long id = c.getLong(c.getColumnIndexOrThrow("id"));
            String name = c.getString(c.getColumnIndexOrThrow("title")); String copy = c.getString(c.getColumnIndexOrThrow("body"));
            String platform = safe(c.getString(c.getColumnIndexOrThrow("platform"))); String when = safe(c.getString(c.getColumnIndexOrThrow("publish_at")));
            String status = c.getString(c.getColumnIndexOrThrow("status"));
            card(body); label(body, platform + "  •  " + status.toUpperCase()); title(body, name);
            if (!when.isEmpty()) smallNote(body, "Planned: " + when);
            if (copy != null && !copy.isEmpty()) paragraph(body, copy);
            LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button share = button("Share / publish", true); actions.addView(share, new LinearLayout.LayoutParams(0, dp(44), 1));
            final String shareText = (name + "\n\n" + safe(copy)).trim();
            share.setOnClickListener(v -> shareText(shareText));
            Button del = button("Delete", false); LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(90), dp(44)); dlp.setMargins(dp(8), 0, 0, 0); actions.addView(del, dlp);
            del.setOnClickListener(v -> { db.deleteRow("posts", id); render(); }); body.addView(actions);
        }
        c.close(); if (!any) emptyHint("No content planned yet", "Create a draft, add a platform and set a target date.");
    }

    private void showInbox() {
        title(body, "DMs & comments"); paragraph(body, "A workspace-separated inbox log. Add conversations manually for now; live account syncing and auto-replies need official platform API access.");
        addButton(body, "+  Log a DM / comment", true, this::showAddInbox);
        Cursor c = db.list("inbox_notes", businessId); boolean any = false;
        while (c.moveToNext()) {
            any = true; long id = c.getLong(c.getColumnIndexOrThrow("id")); String person = safe(c.getString(c.getColumnIndexOrThrow("person")));
            String message = c.getString(c.getColumnIndexOrThrow("message")); String platform = safe(c.getString(c.getColumnIndexOrThrow("platform")));
            String kind = c.getString(c.getColumnIndexOrThrow("kind")); String status = c.getString(c.getColumnIndexOrThrow("status"));
            card(body); label(body, platform + "  •  " + kind + "  •  " + status); title(body, person.isEmpty() ? "Unknown contact" : person); paragraph(body, message);
            LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button handled = button(status.equals("Handled") ? "Reopen" : "Mark handled", true); actions.addView(handled, new LinearLayout.LayoutParams(0, dp(42), 1));
            handled.setOnClickListener(v -> { db.setStatus("inbox_notes", id, status.equals("Handled") ? "Open" : "Handled"); render(); });
            Button del = button("Delete", false); LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(90), dp(42)); dlp.setMargins(dp(8), 0, 0, 0); actions.addView(del, dlp); del.setOnClickListener(v -> { db.deleteRow("inbox_notes", id); render(); }); body.addView(actions);
        }
        c.close(); if (!any) emptyHint("Inbox is clear", "Add a DM or comment note to track a follow-up.");
        sectionTitle(body, "Reply templates");
        addButton(body, "+  Create keyword reply rule", false, this::showAddRule);
        Cursor r = db.list("reply_rules", businessId); while (r.moveToNext()) { card(body); label(body, "KEYWORD  •  " + safe(r.getString(r.getColumnIndexOrThrow("channel")))); title(body, "When they say: " + r.getString(r.getColumnIndexOrThrow("trigger_word"))); paragraph(body, r.getString(r.getColumnIndexOrThrow("reply_text"))); smallNote(body, "Saved as a draft rule — not connected to a live social account."); } r.close();
    }

    private void showLeads() {
        title(body, "Leads & customers"); paragraph(body, "Keep track of people who may become customers for this business.");
        addButton(body, "+  Add lead", true, this::showAddLead);
        Cursor c = db.list("leads", businessId); boolean any = false;
        while (c.moveToNext()) {
            any = true; long id = c.getLong(c.getColumnIndexOrThrow("id")); String name = c.getString(c.getColumnIndexOrThrow("name"));
            String contact = safe(c.getString(c.getColumnIndexOrThrow("contact"))); String source = safe(c.getString(c.getColumnIndexOrThrow("source")));
            String stage = c.getString(c.getColumnIndexOrThrow("stage")); String notes = safe(c.getString(c.getColumnIndexOrThrow("notes")));
            card(body); label(body, stage.toUpperCase() + (source.isEmpty() ? "" : "  •  " + source)); title(body, name);
            if (!contact.isEmpty()) paragraph(body, contact); if (!notes.isEmpty()) smallNote(body, notes);
            LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button next = button(nextStage(stage), true); actions.addView(next, new LinearLayout.LayoutParams(0, dp(42), 1));
            next.setOnClickListener(v -> { db.setStatus("leads", id, nextStage(stage)); render(); });
            Button del = button("Delete", false); LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(90), dp(42)); dlp.setMargins(dp(8), 0, 0, 0); actions.addView(del, dlp); del.setOnClickListener(v -> { db.deleteRow("leads", id); render(); }); body.addView(actions);
        }
        c.close(); if (!any) emptyHint("No leads yet", "Add people who show interest in your product or service.");
    }

    private void showSetup() {
        title(body, "Business setup"); paragraph(body, "Every business has a separate account list and its own automation drafts.");
        card(body); title(body, businessName); paragraph(body, "Workspace ID: " + businessId); smallNote(body, "Local-only workspace on this device. No cloud sync or user login is enabled yet.");
        sectionTitle(body, "Social profiles"); addButton(body, "+  Add social profile", true, this::showAddChannel);
        Cursor c = db.list("channels", businessId); boolean any = false;
        while (c.moveToNext()) { any = true; long id = c.getLong(c.getColumnIndexOrThrow("id")); String platform = c.getString(c.getColumnIndexOrThrow("platform")); String handle = c.getString(c.getColumnIndexOrThrow("handle")); String note = safe(c.getString(c.getColumnIndexOrThrow("note")));
            card(body); title(body, platform); paragraph(body, handle); if (!note.isEmpty()) smallNote(body, note); Button del = button("Remove profile", false); body.addView(del); del.setOnClickListener(v -> { db.deleteRow("channels", id); render(); });
        } c.close(); if (!any) emptyHint("No profiles saved", "Add the handles you use for this business. Saving a profile does not connect its platform API.");
        sectionTitle(body, "Important");
        card(body); title(body, "What is live in this APK?");
        paragraph(body, "✓ Separate business workspaces\n✓ Local content calendar and share handoff\n✓ Lead tracker\n✓ Manual inbox log\n✓ Reply-rule drafts\n\nNot live yet: official social account OAuth, automatic publishing, synced comments/DMs, auto-DM triggers, background cloud scheduling and team access.");
    }

    private void showAddBusiness() {
        LinearLayout form = form(); EditText name = field("Business name"); EditText niche = field("Industry / niche (optional)"); form.addView(name); form.addView(niche);
        new AlertDialog.Builder(this).setTitle("Create business workspace").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Create", (d,w) -> {
            String n = value(name); if (n.isEmpty()) { toast("Enter a business name"); return; }
            long id = db.addBusiness(n, value(niche)); if (id > 0) { businessId = id; businessName = n; getPreferences(0).edit().putLong("business_id", id).apply(); tab = "Overview"; render(); }
        }).show();
    }

    private void chooseBusiness() {
        List<Long> ids = new ArrayList<>(); List<String> names = new ArrayList<>(); Cursor c = db.listBusinesses();
        while (c.moveToNext()) { ids.add(c.getLong(0)); names.add(c.getString(c.getColumnIndexOrThrow("name"))); } c.close();
        names.add("+  Add another business"); String[] items = names.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Switch business").setItems(items, (d, which) -> {
            if (which == names.size() - 1) { showAddBusiness(); return; }
            businessId = ids.get(which); businessName = names.get(which); getPreferences(0).edit().putLong("business_id", businessId).apply(); render();
        }).show();
    }

    private void showAddChannel() {
        LinearLayout f = form(); EditText platform = field("Platform (Instagram, Facebook, LinkedIn...)"); EditText handle = field("Profile name / @handle"); EditText note = field("Notes (optional)"); f.addView(platform); f.addView(handle); f.addView(note);
        new AlertDialog.Builder(this).setTitle("Save social profile").setView(f).setNegativeButton("Cancel", null).setPositiveButton("Save", (d,w) -> { if (value(platform).isEmpty() || value(handle).isEmpty()) { toast("Enter platform and profile handle"); return; } db.addChannel(businessId, value(platform), value(handle), value(note)); render(); }).show();
    }

    private void showAddPost() {
        LinearLayout f = form(); EditText title = field("Post title / internal label"); EditText platform = field("Target platform (optional)"); EditText when = field("Planned date and time (optional)"); EditText copy = field("Post caption / content"); copy.setMinLines(4); copy.setGravity(Gravity.TOP); f.addView(title); f.addView(platform); f.addView(when); f.addView(copy);
        new AlertDialog.Builder(this).setTitle("Plan content").setView(f).setNegativeButton("Cancel", null).setPositiveButton("Save draft", (d,w) -> { if (value(title).isEmpty()) { toast("Add a post title"); return; } db.addPost(businessId, value(title), value(copy), value(platform), value(when), "Draft"); tab = "Content"; render(); }).show();
    }

    private void showAddLead() {
        LinearLayout f = form(); EditText name = field("Person / company name"); EditText contact = field("Email, phone or profile link"); EditText source = field("Where did you find them? (Reddit, Instagram...)"); EditText notes = field("Notes / need / next step"); f.addView(name); f.addView(contact); f.addView(source); f.addView(notes);
        new AlertDialog.Builder(this).setTitle("Add lead").setView(f).setNegativeButton("Cancel", null).setPositiveButton("Save lead", (d,w) -> { if (value(name).isEmpty()) { toast("Enter a name"); return; } db.addLead(businessId, value(name), value(contact), value(source), "New", value(notes)); tab = "Leads"; render(); }).show();
    }

    private void showAddInbox() {
        LinearLayout f = form(); EditText platform = field("Platform"); EditText person = field("Person / account"); EditText kind = field("Type: DM or Comment"); EditText message = field("Message / comment"); message.setMinLines(3); f.addView(platform); f.addView(person); f.addView(kind); f.addView(message);
        new AlertDialog.Builder(this).setTitle("Log conversation").setView(f).setNegativeButton("Cancel", null).setPositiveButton("Save", (d,w) -> { if (value(message).isEmpty()) { toast("Add a message"); return; } String k = value(kind).isEmpty() ? "DM" : value(kind); db.addInbox(businessId, value(platform), value(person), value(message), k); tab = "Inbox"; render(); }).show();
    }

    private void showAddRule() {
        LinearLayout f = form(); EditText keyword = field("When a message/comment contains..."); EditText channel = field("Platform (optional)"); EditText reply = field("Suggested reply text"); reply.setMinLines(3); f.addView(keyword); f.addView(channel); f.addView(reply);
        new AlertDialog.Builder(this).setTitle("Draft keyword reply rule").setView(f).setNegativeButton("Cancel", null).setPositiveButton("Save rule", (d,w) -> { if (value(keyword).isEmpty() || value(reply).isEmpty()) { toast("Enter a keyword and reply"); return; } db.addRule(businessId, value(keyword), value(reply), value(channel)); render(); }).show();
    }

    private void shareText(String content) {
        Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT, content);
        startActivity(Intent.createChooser(send, "Share post with"));
    }

    private void stat(LinearLayout row, String label, int number) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(11), dp(13), dp(8), dp(13)); box.setBackground(round(CARD, 16));
        TextView n = text(String.valueOf(number), 23, INK, true); TextView l = text(label, 9, MUTED, true); box.addView(n); box.addView(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(78), 1); p.setMargins(dp(3), 0, dp(3), 0); row.addView(box, p);
    }
    private void card(LinearLayout parent) { activeCard = null; LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(15), dp(14), dp(15), dp(14)); c.setBackground(round(CARD, 18)); LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin = dp(10); parent.addView(c, p); if (parent == body) activeCard = c; }
    private LinearLayout destination(LinearLayout requested) { return requested == body && activeCard != null ? activeCard : requested; }
    private void title(LinearLayout p, String s) { TextView v = text(s, 17, INK, true); v.setPadding(0, dp(2), 0, dp(7)); destination(p).addView(v); }
    private void paragraph(LinearLayout p, String s) { TextView v = text(s, 13, MUTED, false); v.setLineSpacing(dp(3), 1f); v.setPadding(0, 0, 0, dp(8)); destination(p).addView(v); }
    private void label(LinearLayout p, String s) { TextView v = text(s.toUpperCase(), 10, PURPLE, true); v.setPadding(0, 0, 0, dp(7)); destination(p).addView(v); }
    private void smallNote(LinearLayout p, String s) { TextView v = text(s, 11, MUTED, false); v.setPadding(0, dp(2), 0, dp(9)); destination(p).addView(v); }
    private void sectionTitle(LinearLayout p, String s) { if (p == body) activeCard = null; TextView v = text(s, 15, INK, true); v.setPadding(0, dp(16), 0, dp(9)); p.addView(v); }
    private void emptyHint(String head, String detail) { card(body); title(body, head); paragraph(body, detail); }
    private void addButton(LinearLayout p, String text, boolean primary, Runnable action) { if (p == body) activeCard = null; Button b = button(text, primary); LinearLayout.LayoutParams lp = matchWrap(); lp.bottomMargin = dp(8); p.addView(b, lp); b.setOnClickListener(v -> action.run()); }
    private Button button(String s, boolean primary) { Button b = new Button(this); b.setText(s); b.setTextSize(13); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(primary ? Color.WHITE : INK); b.setMinHeight(dp(44)); b.setMinimumHeight(dp(44)); b.setPadding(dp(12), dp(5), dp(12), dp(5)); b.setBackground(round(primary ? PURPLE : Color.WHITE, 13)); return b; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private EditText field(String hint) { EditText e = new EditText(this); e.setSingleLine(false); e.setTextSize(14); e.setHint(hint); e.setPadding(dp(12), dp(9), dp(12), dp(9)); e.setBackground(round(Color.rgb(246,247,251), 12)); LinearLayout.LayoutParams lp = matchWrap(); lp.bottomMargin = dp(9); e.setLayoutParams(lp); return e; }
    private LinearLayout form() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18), dp(8), dp(18), dp(2)); return l; }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private String value(EditText e) { return e.getText().toString().trim(); }
    private String safe(String s) { return s == null ? "" : s; }
    private String nextStage(String s) { switch (s) { case "New": return "Contacted"; case "Contacted": return "Interested"; case "Interested": return "Customer"; default: return "New"; } }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
