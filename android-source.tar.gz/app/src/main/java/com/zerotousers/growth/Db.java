package com.zerotousers.growth;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Db extends SQLiteOpenHelper {
    public Db(Context c) { super(c, "zerotousers.db", null, 1); }

    @Override public void onConfigure(SQLiteDatabase db) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE businesses(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, niche TEXT, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE channels(id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL, platform TEXT NOT NULL, handle TEXT NOT NULL, note TEXT, FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE posts(id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL, title TEXT NOT NULL, body TEXT, platform TEXT, publish_at TEXT, status TEXT NOT NULL DEFAULT 'Draft', created_at INTEGER NOT NULL, FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE leads(id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL, name TEXT NOT NULL, contact TEXT, source TEXT, stage TEXT NOT NULL DEFAULT 'New', notes TEXT, created_at INTEGER NOT NULL, FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE inbox_notes(id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL, platform TEXT, person TEXT, message TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'DM', status TEXT NOT NULL DEFAULT 'Open', created_at INTEGER NOT NULL, FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE CASCADE)");
        db.execSQL("CREATE TABLE reply_rules(id INTEGER PRIMARY KEY AUTOINCREMENT, business_id INTEGER NOT NULL, trigger_word TEXT NOT NULL, reply_text TEXT NOT NULL, channel TEXT, enabled INTEGER NOT NULL DEFAULT 1, FOREIGN KEY(business_id) REFERENCES businesses(id) ON DELETE CASCADE)");
        db.execSQL("PRAGMA foreign_keys=ON");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    public long addBusiness(String name, String niche) {
        ContentValues v = new ContentValues(); v.put("name", name); v.put("niche", niche); v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("businesses", null, v);
    }
    public long addChannel(long businessId, String platform, String handle, String note) {
        ContentValues v = new ContentValues(); v.put("business_id", businessId); v.put("platform", platform); v.put("handle", handle); v.put("note", note);
        return getWritableDatabase().insert("channels", null, v);
    }
    public long addPost(long businessId, String title, String body, String platform, String when, String status) {
        ContentValues v = new ContentValues(); v.put("business_id", businessId); v.put("title", title); v.put("body", body); v.put("platform", platform); v.put("publish_at", when); v.put("status", status); v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("posts", null, v);
    }
    public long addLead(long businessId, String name, String contact, String source, String stage, String notes) {
        ContentValues v = new ContentValues(); v.put("business_id", businessId); v.put("name", name); v.put("contact", contact); v.put("source", source); v.put("stage", stage); v.put("notes", notes); v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("leads", null, v);
    }
    public long addInbox(long businessId, String platform, String person, String message, String kind) {
        ContentValues v = new ContentValues(); v.put("business_id", businessId); v.put("platform", platform); v.put("person", person); v.put("message", message); v.put("kind", kind); v.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("inbox_notes", null, v);
    }
    public long addRule(long businessId, String trigger, String reply, String channel) {
        ContentValues v = new ContentValues(); v.put("business_id", businessId); v.put("trigger_word", trigger); v.put("reply_text", reply); v.put("channel", channel);
        return getWritableDatabase().insert("reply_rules", null, v);
    }
    public void setStatus(String table, long id, String status) {
        if (!table.equals("posts") && !table.equals("leads") && !table.equals("inbox_notes")) return;
        ContentValues v = new ContentValues(); v.put(table.equals("leads") ? "stage" : "status", status); getWritableDatabase().update(table, v, "id=?", new String[]{String.valueOf(id)});
    }
    public Cursor list(String table, long businessId) {
        String order = table.equals("posts") ? "created_at DESC" : "id DESC";
        return getReadableDatabase().rawQuery("SELECT * FROM " + table + " WHERE business_id=? ORDER BY " + order, new String[]{String.valueOf(businessId)});
    }
    public Cursor listBusinesses() { return getReadableDatabase().rawQuery("SELECT * FROM businesses ORDER BY id DESC", null); }
    public int count(String table, long businessId) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + table + " WHERE business_id=?", new String[]{String.valueOf(businessId)});
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }
    public void deleteRow(String table, long id) {
        if (!table.equals("channels") && !table.equals("posts") && !table.equals("leads") && !table.equals("inbox_notes") && !table.equals("reply_rules")) return;
        getWritableDatabase().delete(table, "id=?", new String[]{String.valueOf(id)});
    }
}
